// @ flow
import button_props from '../props/ButtonProps.js';

export type ButtonType = {
  disabled?: bool,
  delete?: bool,
  definition?: "primary"| "warning",
  children?: string,
  onClick?: ()=> void
};

