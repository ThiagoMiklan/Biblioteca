import React, { useState } from 'react';
import ReactDOM from 'react-dom';
import 'bulma/css/bulma.css';

ReactDOM.render(

    <button className="button is-warning">Button Warning</button>
  
    , document.getElementById("root"))


