const pagination_props = {
    "small": "is-small",
    "medium": "is-medium",
    "large": "is-large",

    "rounded": "is-rounded",
    "right" : "is-right",
    "left": "is-left",
    "center": "is-centered",

    "current" : "is-current"

}

export default pagination_props;