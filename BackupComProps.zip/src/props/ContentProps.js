const content_props = {
        "small" : "is-small",
        "medium" : "is-medium",
        "large" : "is-large",
        "content" : "content"
}

export default content_props;