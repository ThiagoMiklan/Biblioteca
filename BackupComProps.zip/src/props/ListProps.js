const list_props = 
{
    "lower-alpha":"is-lower-alpha",
    "lower-roman":"is-lower-roman",
    "upper-alpha": "is-upper-alpha",
    "upper-roman": "is-upper-roman",

}


export default list_props;
