import global_props from './GlobalProps';

const columns_props ={
        "centered" : "is-centered",
        "columns": "columns",
        "multiline": "is-multiline",
        "1": "is-1",
        "2": "is-2",
        "3": "is-3",
        "4": "is-4",
        "5": "is-5",
        "6": "is-6",
        "7": "is-7",
        "8": "is-8",
        "9": "is-9",
        "10": "is-10",
        "11": "is-11",
        "12": "is-12"
}

export default columns_props