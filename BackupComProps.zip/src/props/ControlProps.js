const control_props ={
    "control" : "control",
    "icons-left" : "has-icons-left",
    "icons-right" :"has-icons-right",
    // loading utilizado por exemplo no textarea
    "loading" : "is-loading"
}



export default control_props;