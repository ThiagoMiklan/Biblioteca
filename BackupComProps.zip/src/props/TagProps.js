var tag_props ={
    "tag":"tag",
    "black":"is-black",
    "dark": "is-dark",
    "light":"is-light",
    "white": "is-white",
    "primary": "is-primary",
    "link":"is-link",
    "info": "is-info",
    "success": "is-success",
    "warning": "is-warning",
    "danger": "is-danger",
    "medium":"is-medium",
    "large":"is-large",
    "rounded":"is-rounded",
    "tags":"tags"
}

export default tag_props;