const section_props ={
    

}

export default section_props;