

var global_props = {
    "background-white": "has-background-white",
    "background-black": "has-background-black",
    "background-light": "has-background-light",
    "background-dark": "has-background-dark,",
    "background-primary": "has-background-primary",
    "background-info": "has-background-info",
    "background-link": "has-background-link",
    "background-success": "has-background-success",
    "background-warning": "has-background-warning",
    "background-danger": "has-background-danger",
    "background-black-bis": "has-background-black-bis",
    "background-black-ter": "has-background-black-ter",
    "background-grey-darker": "has-background-grey-darker",
    "background-grey-dark": "has-background-grey-dark",
    "background-grey": "has-background-grey",
    "background-grey-light": "has-background-grey-light",
    "background-grey-lighter": "has-background-grey-lighter",
    "background-white-ter": "has-background-white-ter",
    "background-white-bis": "has-background-white-bis",

    "text-white": "has-text-white",
    "text-black": "has-text-black",
    "text-light": "has-text-light",
    "text-dark": "has-text-dark",
    "text-primary": "has-text-primary",
    "text-info": "has-text-info",
    "text-link": "has-text-link",
    "text-success": "has-text-success",
    "text-warning": "has-text-warning",
    "text-danger": "has-text-danger",
    "text-black-bis": "has-text-black-bis",
    "text-black-ter": "has-text-black-ter",
    "text-grey-darker": "has-text-grey-darker",
    "text-grey-dark": "has-text-grey-dark",
    "text-grey": "has-text-grey",
    "text-grey-light": "has-text-grey-light",
    "text-grey-lighter": "has-text-grey-lighter",
    "text-white-ter": "has-text-white-ter",
    "text-white-bis": "has-text-white-bis",

    "tile": "is-tile",
    "child": "is-childt"
}

export default global_props;