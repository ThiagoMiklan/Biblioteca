
const tag_list_props ={
    "medium": "is-medium",
    "large":"is-large",
    "tabs": "tabs",
    "addons": "has-addons"
}

export default tag_list_props;