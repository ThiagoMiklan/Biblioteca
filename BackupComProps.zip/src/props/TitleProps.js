
const title_props ={
    "subtitle" : "subtitle",
    "title": "title",
    "1" : "is-1",
    "2":"is-2",
    "3":"is-3",
    "4": "is-4",
    "5": "is-5",
    "6": "is-6",
    "spaced": "is-spaced"
}

export default title_props;