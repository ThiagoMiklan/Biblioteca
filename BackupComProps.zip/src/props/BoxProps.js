const box_props = {};

export default box_props;
