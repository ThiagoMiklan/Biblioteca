const panel_props ={
    "active" : "is-active",
    "primary": "is-primary",
    "link": "is-link",
    "info": "is-info",
    "success": "is-success",
    "warning": "is-warning",
    "danger": "is-danger"
}

export default panel_props;