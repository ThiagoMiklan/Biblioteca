import global_props from './GlobalProps';

const message_props ={
    "primary": "is-primary",
    "warning": "is-warning",
    "info": "is-info",
    "danger": "is-danger",
    "success" : "is-success",
    "link" : "is-link",
    "dark" : "is-dark",

    "small": "is-small",
    "medium": "is-medium",
    "large": "is-large"
}

export default message_props;