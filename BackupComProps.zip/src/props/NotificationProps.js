import global_props from './GlobalProps';

const notification_props = {
    //cores
    "primary":"is-primary",
    "link": "is-link",
    "warning": "is-warning",
    "info": "is-info",
    "danger": "is-danger",
    "success": "is-success",
   
    // opção do botão delete
    "delete" :"delete",

    //light
    'light' : "is-light",

}

export default {...notification_props,...global_props};