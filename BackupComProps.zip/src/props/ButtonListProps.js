const button_list ={
    "small": "are-small",
    "medium": "are-medium",
    "large": "are-large",
    "buttons": "buttons",
    "addons" : "has-addons",
    "grouped": "is-grouped",
    "centered": "is-centered",
    "right": "is-right",
    "field": "field"
}

export default button_list;