
const progress_bar_props = {
          "progress":"progress",
          "primary":"is-primary",
          "link": "is-link",
          "warning": "is-warning",
          "info": "is-info",
          "danger": "is-danger",
          "success": "is-sucess",
          "medium": "is-medium",
          "small": "is-small",
          "large": "is-large",
          "dark": "is-dark"
}


export default progress_bar_props;

