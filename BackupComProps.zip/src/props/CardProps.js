import global_props from './GlobalProps';

const card_props = {
    "centered": "is-centered"    
}

export default {...card_props,...global_props};