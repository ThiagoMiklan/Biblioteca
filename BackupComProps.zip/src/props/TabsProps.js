const tabs_props ={
    "centered" : "is-centered",
    "right" : "is-right",
    "small" : "is-small",
    "medium": "is-medium",
    "large" : "is-large",
    "toggle": "is-toggle",
    "boxed" : "is-boxed",
    "rounded": 'is-rounded',
    "fullwidth" : "is-fullwidth",
    "active" : "is-active",
    "toggle-rounded": "is-toggle-rounded"
}

export default tabs_props;