const menu_props ={
    "active": "is-active",
    "label": "menu-label",
    "list": "menu-list",
    "menu": "menu"
}

export default menu_props;