
const definition_err = "Definition Exception - The following characteristics are not defined:";

export{definition_err};